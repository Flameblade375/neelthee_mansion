from . import Mansion_of_Amnesia

if __name__ == "__main__":
    Mansion_of_Amnesia.main()
